#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>

// Configuration for student data and visual styling
#define STARTING_CAPACITY 5
#define MAX_NAME_LEN 60
#define DATE_LEN 11 // For "YYYY-MM-DD"
#define ANSI_RESET "\033[0m"
#define ANSI_GREEN "\033[0;32m"
#define ANSI_RED "\033[0;31m"
#define ANSI_BLUE "\033[0;34m"
#define ANSI_YELLOW "\033[0;33m"
#define ANSI_CYAN "\033[0;36m"

// Structure to hold individual student information
typedef struct {
    char studentName[MAX_NAME_LEN];
    int studentId;
    float studentScore;
    char lastModified[DATE_LEN];
} StudentEntry;

// Structure to manage collection of student records
typedef struct {
    StudentEntry *entries;
    int currentSize;
    int maxSize;
} StudentDatabase;

// Function declarations
void setupDatabase(StudentDatabase *db);
void cleanupDatabase(StudentDatabase *db);
void insertStudent(StudentDatabase *db);
void deleteStudent(StudentDatabase *db, int id);
void updateStudent(StudentDatabase *db, int id);
void showAllStudents(const StudentDatabase *db);
void showStudentDetails(const StudentEntry *entry);
StudentEntry* findStudentById(const StudentDatabase *db, int id);
float computeAverageScore(const StudentDatabase *db);
void orderByScore(StudentDatabase *db, int ascendingOrder);
int scoreCompareAsc(const void *first, const void *second);
int scoreCompareDesc(const void *first, const void *second);
void saveRecordsToFile(const StudentDatabase *db, const char *filePath);
void loadRecordsFromFile(StudentDatabase *db, const char *filePath);
void printMenu();
void welcomeMessage();
void refreshScreen();
void getCurrentDate(char *dateStr);
int confirmInput(const char *prompt, const char *value);
int getValidId(const char *prompt);
float getValidScore(const char *prompt);
void getValidName(char *name, const char *prompt);
void getValidFilePath(char *filePath, const char *prompt);

int main() {
    StudentDatabase db;
    setupDatabase(&db);

    refreshScreen();
    welcomeMessage();

    int userChoice;
    do {
        refreshScreen();
        printMenu();
        printf("%sSelect an option: %s", ANSI_YELLOW, ANSI_RESET);
        scanf("%d", &userChoice);
        getchar(); // Clear input buffer

        refreshScreen();
        switch (userChoice) {
            case 1: insertStudent(&db); break;
            case 2: {
                int id = getValidId("Enter student ID to delete");
                deleteStudent(&db, id);
                break;
            }
            case 3: {
                int id = getValidId("Enter student ID to update");
                updateStudent(&db, id);
                break;
            }
            case 4: showAllStudents(&db); break;
            case 5: {
                int id = getValidId("Enter student ID to find");
                StudentEntry *entry = findStudentById(&db, id);
                if (entry) {
                    showStudentDetails(entry);
                } else {
                    printf("%sNo student found with ID %d.%s\n", ANSI_RED, id, ANSI_RESET);
                }
                break;
            }
            case 6: {
                float avg = computeAverageScore(&db);
                printf("%sAverage score: %.2f%s\n", ANSI_CYAN, avg, ANSI_RESET);
                break;
            }
            case 7: {
                orderByScore(&db, 1);
                printf("%sStudents ordered by score (ascending).%s\n", ANSI_GREEN, ANSI_RESET);
                showAllStudents(&db);
                break;
            }
            case 8: {
                orderByScore(&db, 0);
                printf("%sStudents ordered by score (descending).%s\n", ANSI_GREEN, ANSI_RESET);
                showAllStudents(&db);
                break;
            }
            case 9: {
                char filePath[100];
                getValidFilePath(filePath, "Enter file name to save records (e.g., students.csv)");
                saveRecordsToFile(&db, filePath);
                break;
            }
            case 10: {
                char filePath[100];
                getValidFilePath(filePath, "Enter file name to load records (e.g., students.csv)");
                loadRecordsFromFile(&db, filePath);
                break;
            }
            case 11: {
                printf("%sThank you for using the Student Database!%s\n", ANSI_GREEN, ANSI_RESET);
                break;
            }
            default: {
                printf("%sInvalid option. Please select a valid menu item.%s\n", ANSI_RED, ANSI_RESET);
            }
        }
        if (userChoice != 11) {
            printf("\n%sPress Enter to continue...%s", ANSI_YELLOW, ANSI_RESET);
            getchar();
        }
    } while (userChoice != 11);

    cleanupDatabase(&db);
    return 0;
}

void setupDatabase(StudentDatabase *db) {
    db->entries = (StudentEntry *)malloc(STARTING_CAPACITY * sizeof(StudentEntry));
    if (!db->entries) {
        fprintf(stderr, "%sError: Unable to allocate initial memory.%s\n", ANSI_RED, ANSI_RESET);
        exit(1);
    }
    db->currentSize = 0;
    db->maxSize = STARTING_CAPACITY;
}

void cleanupDatabase(StudentDatabase *db) {
    free(db->entries);
    db->entries = NULL;
    db->currentSize = 0;
    db->maxSize = 0;
}

void getCurrentDate(char *dateStr) {
    time_t now = time(NULL);
    struct tm *t = localtime(&now);
    snprintf(dateStr, DATE_LEN, "%04d-%02d-%02d", t->tm_year + 1900, t->tm_mon + 1, t->tm_mday);
}

int confirmInput(const char *prompt, const char *value) {
    char choice;
    printf("%s%s: %s. Is this correct? (y/n): %s", ANSI_YELLOW, prompt, value, ANSI_RESET);
    scanf(" %c", &choice);
    getchar(); // Clear newline
    return tolower(choice) == 'y';
}

int getValidId(const char *prompt) {
    int id;
    char idStr[20];
    do {
        printf("%s%s: %s", ANSI_YELLOW, prompt, ANSI_RESET);
        scanf("%d", &id);
        getchar();
        snprintf(idStr, sizeof(idStr), "%d", id);
    } while (!confirmInput(prompt, idStr));
    return id;
}

float getValidScore(const char *prompt) {
    float score;
    char scoreStr[20];
    do {
        printf("%s%s: %s", ANSI_YELLOW, prompt, ANSI_RESET);
        scanf("%f", &score);
        getchar();
        snprintf(scoreStr, sizeof(scoreStr), "%.2f", score);
    } while (!confirmInput(prompt, scoreStr));
    return score;
}

void getValidName(char *name, const char *prompt) {
    do {
        printf("%s%s: %s", ANSI_YELLOW, prompt, ANSI_RESET);
        fgets(name, MAX_NAME_LEN, stdin);
        name[strcspn(name, "\n")] = '\0';
    } while (!confirmInput(prompt, name));
}

void getValidFilePath(char *filePath, const char *prompt) {
    do {
        printf("%s%s: %s", ANSI_YELLOW, prompt, ANSI_RESET);
        scanf("%s", filePath);
        getchar();
    } while (!confirmInput(prompt, filePath));
}

void insertStudent(StudentDatabase *db) {
    if (db->currentSize >= db->maxSize) {
        db->maxSize *= 2;
        db->entries = (StudentEntry *)realloc(db->entries, db->maxSize * sizeof(StudentEntry));
        if (!db->entries) {
            fprintf(stderr, "%sError: Memory expansion failed.%s\n", ANSI_RED, ANSI_RESET);
            exit(1);
        }
    }

    StudentEntry *newEntry = &db->entries[db->currentSize];
    getValidName(newEntry->studentName, "Enter student name");
    newEntry->studentId = getValidId("Enter student ID");
    newEntry->studentScore = getValidScore("Enter student score");
    getCurrentDate(newEntry->lastModified);
    db->currentSize++;
    printf("%sStudent record created successfully.%s\n", ANSI_GREEN, ANSI_RESET);
}

void deleteStudent(StudentDatabase *db, int id) {
    int found = 0;
    for (int i = 0; i < db->currentSize; i++) {
        if (db->entries[i].studentId == id) {
            for (int j = i; j < db->currentSize - 1; j++) {
                db->entries[j] = db->entries[j + 1];
            }
            db->currentSize--;
            found = 1;
            printf("%sStudent with ID %d removed.%s\n", ANSI_GREEN, id, ANSI_RESET);
            break;
        }
    }
    if (!found) {
        printf("%sNo student found with ID %d.%s\n", ANSI_RED, id, ANSI_RESET);
    }
}

void updateStudent(StudentDatabase *db, int id) {
    StudentEntry *entry = findStudentById(db, id);
    if (entry) {
        getValidName(entry->studentName, "Enter new name (current: %s)");
        entry->studentId = getValidId("Enter new ID (current: %d)");
        entry->studentScore = getValidScore("Enter new score (current: %.2f)");
        getCurrentDate(entry->lastModified);
        printf("%sStudent record updated successfully.%s\n", ANSI_GREEN, ANSI_RESET);
    } else {
        printf("%sNo student found with ID %d.%s\n", ANSI_RED, id, ANSI_RESET);
    }
}

void showAllStudents(const StudentDatabase *db) {
    if (db->currentSize == 0) {
        printf("%sNo student records available.%s\n", ANSI_RED, ANSI_RESET);
        return;
    }
    printf("%s+-------------------------------------------------+--------------+---------+----------+------------+%s\n", ANSI_BLUE, ANSI_RESET);
    printf("%s| Student Name                                    | ID           | Score   | Status   | Modified   |%s\n", ANSI_BLUE, ANSI_RESET);
    printf("%s+-------------------------------------------------+--------------+---------+----------+------------+%s\n", ANSI_BLUE, ANSI_RESET);
    for (int i = 0; i < db->currentSize; i++) {
        const StudentEntry *e = &db->entries[i];
        const char *statusColor = (e->studentScore > 40.0) ? ANSI_GREEN : ANSI_RED;
        printf("| %-47s | %-12d | %-7.2f | %s%-8s%s | %-10s |\n", e->studentName, e->studentId, e->studentScore, statusColor, (e->studentScore > 40.0 ? "Passed" : "Failed"), ANSI_RESET, e->lastModified);
    }
    printf("%s+-------------------------------------------------+--------------+---------+----------+------------+%s\n", ANSI_BLUE, ANSI_RESET);
}

void showStudentDetails(const StudentEntry *entry) {
    const char *statusColor = (entry->studentScore > 40.0) ? ANSI_GREEN : ANSI_RED;
    printf("%s+-------------------------------------------------+--------------+---------+----------+------------+%s\n", ANSI_BLUE, ANSI_RESET);
    printf("%s| Student Name                                    | ID           | Score   | Status   | Modified   |%s\n", ANSI_BLUE, ANSI_RESET);
    printf("%s+-------------------------------------------------+--------------+---------+----------+------------+%s\n", ANSI_BLUE, ANSI_RESET);
    printf("| %-47s | %-12d | %-7.2f | %s%-8s%s | %-10s |\n", entry->studentName, entry->studentId, entry->studentScore, statusColor, (entry->studentScore > 40.0 ? "Passed" : "Failed"), ANSI_RESET, entry->lastModified);
    printf("%s+-------------------------------------------------+--------------+---------+----------+------------+%s\n", ANSI_BLUE, ANSI_RESET);
}

StudentEntry* findStudentById(const StudentDatabase *db, int id) {
    for (int i = 0; i < db->currentSize; i++) {
        if (db->entries[i].studentId == id) {
            return &db->entries[i];
        }
    }
    return NULL;
}

float computeAverageScore(const StudentDatabase *db) {
    if (db->currentSize == 0) return 0.0;
    float total = 0.0;
    for (int i = 0; i < db->currentSize; i++) {
        total += db->entries[i].studentScore;
    }
    return total / db->currentSize;
}

void orderByScore(StudentDatabase *db, int ascendingOrder) {
    if (ascendingOrder) {
        qsort(db->entries, db->currentSize, sizeof(StudentEntry), scoreCompareAsc);
    } else {
        qsort(db->entries, db->currentSize, sizeof(StudentEntry), scoreCompareDesc);
    }
}

int scoreCompareAsc(const void *first, const void *second) {
    float scoreA = ((StudentEntry *)first)->studentScore;
    float scoreB = ((StudentEntry *)second)->studentScore;
    return (scoreA > scoreB) - (scoreA < scoreB);
}

int scoreCompareDesc(const void *first, const void *second) {
    return scoreCompareAsc(second, first);
}

void saveRecordsToFile(const StudentDatabase *db, const char *filePath) {
    FILE *file = fopen(filePath, "w");
    if (!file) {
        printf("%sError: Could not open file %s for writing.%s\n", ANSI_RED, filePath, ANSI_RESET);
        return;
    }
    // Write header
    if (fprintf(file, "Name,Student ID,Score,Status,Last Modified\n") < 0) {
        printf("%sError: Failed to write header to %s.%s\n", ANSI_RED, filePath, ANSI_RESET);
        fclose(file);
        return;
    }
    // Write each student record
    for (int i = 0; i < db->currentSize; i++) {
        StudentEntry *e = &db->entries[i];
        // Escape quotes in studentName to handle special cases
        char escapedName[MAX_NAME_LEN * 2];
        int j = 0;
        for (int k = 0; e->studentName[k] != '\0' && j < MAX_NAME_LEN * 2 - 1; k++) {
            if (e->studentName[k] == '"') {
                escapedName[j++] = '"';
                escapedName[j++] = '"';
            } else {
                escapedName[j++] = e->studentName[k];
            }
        }
        escapedName[j] = '\0';
        // Write record to file
        if (fprintf(file, "\"%s\",%d,%.2f,%s,%s\n", escapedName, e->studentId, e->studentScore,
                    e->studentScore > 40.0 ? "Passed" : "Failed", e->lastModified) < 0) {
            printf("%sError: Failed to write record %d to %s.%s\n", ANSI_RED, i + 1, filePath, ANSI_RESET);
            fclose(file);
            return;
        }
    }
    fclose(file);
    printf("%sRecords saved to %s successfully.%s\n", ANSI_GREEN, filePath, ANSI_RESET);
}

void loadRecordsFromFile(StudentDatabase *db, const char *filePath) {
    FILE *file = fopen(filePath, "r");
    if (!file) {
        printf("%sError: Could not open file %s for reading.%s\n", ANSI_RED, filePath, ANSI_RESET);
        return;
    }
    db->currentSize = 0; // Reset current records

    char buffer[256];
    if (!fgets(buffer, sizeof(buffer), file)) {
        printf("%sError: File %s is empty or unreadable.%s\n", ANSI_RED, filePath, ANSI_RESET);
        fclose(file);
        return;
    } // Skip header

    char name[MAX_NAME_LEN];
    int id;
    float score;
    char status[10];
    char date[DATE_LEN];
    while (fgets(buffer, sizeof(buffer), file)) {
        // Handle quoted names that may contain commas
        char *nameStart = strchr(buffer, '"');
        if (!nameStart) continue; // Skip malformed lines
        nameStart++; // Skip opening quote
        char *nameEnd = strchr(nameStart, '"');
        if (!nameEnd) continue; // Skip malformed lines
        size_t nameLen = nameEnd - nameStart;
        if (nameLen >= MAX_NAME_LEN) nameLen = MAX_NAME_LEN - 1;
        strncpy(name, nameStart, nameLen);
        name[nameLen] = '\0';

        // Parse remaining fields after the closing quote and comma
        if (sscanf(nameEnd + 2, "%d,%f,%9[^,],%10s", &id, &score, status, date) != 4) {
            printf("%sWarning: Skipping malformed line in %s.%s\n", ANSI_YELLOW, filePath, ANSI_RESET);
            continue;
        }

        if (db->currentSize >= db->maxSize) {
            db->maxSize *= 2;
            db->entries = (StudentEntry *)realloc(db->entries, db->maxSize * sizeof(StudentEntry));
            if (!db->entries) {
                fprintf(stderr, "%sError: Memory expansion failed during file load.%s\n", ANSI_RED, ANSI_RESET);
                fclose(file);
                exit(1);
            }
        }
        strcpy(db->entries[db->currentSize].studentName, name);
        db->entries[db->currentSize].studentId = id;
        db->entries[db->currentSize].studentScore = score;
        strncpy(db->entries[db->currentSize].lastModified, date, DATE_LEN - 1);
        db->entries[db->currentSize].lastModified[DATE_LEN - 1] = '\0';
        db->currentSize++;
    }
    fclose(file);
    printf("%sRecords loaded from %s successfully.%s\n", ANSI_GREEN, filePath, ANSI_RESET);
}

void printMenu() {
    printf("%s================== Student Database ==================%s\n", ANSI_BLUE, ANSI_RESET);
    printf("%s Manage your student records with ease               %s\n", ANSI_CYAN, ANSI_RESET);
    printf("%s================== Menu Options ==================%s\n", ANSI_BLUE, ANSI_RESET);
    printf("1. Insert New Student\n");
    printf("2. Delete Student by ID\n");
    printf("3. Update Student Details\n");
    printf("4. Show All Students\n");
    printf("5. Find Student by ID\n");
    printf("6. Compute Average Score\n");
    printf("7. Order Students by Score (Ascending)\n");
    printf("8. Order Students by Score (Descending)\n");
    printf("9. Save Records to File\n");
    printf("10. Load Records from File\n");
    printf("11. Exit System\n");
    printf("%s=================================================%s\n", ANSI_BLUE, ANSI_RESET);
}

void welcomeMessage() {
    char userName[MAX_NAME_LEN];
    printf("%s=== Welcome to the Student Database System ===%s\n", ANSI_CYAN, ANSI_RESET);
    getValidName(userName, "Enter your name");
    printf("Program Initialised Successfully-%sGreetings, %s! Ready to manage student records.%s\n", ANSI_GREEN, userName, ANSI_RESET);
    printf("\n%sPress Enter to proceed...%s", ANSI_YELLOW, ANSI_RESET);
    getchar();
}

void refreshScreen() {
#ifdef _WIN3211
    system("cls");
#else
    system("clear");
#endif
}